// Signature motif: a wavy scalloped line lifted straight from the
// restaurant's own feature wall. Used as a section-break device instead
// of a generic straight rule or numbered marker.
const ScallopDivider = ({ color = 'var(--terracotta)', flip = false, className = '' }) => (
  <svg
    className={`scallop-divider ${className}`}
    viewBox="0 0 1200 44"
    preserveAspectRatio="none"
    style={{ transform: flip ? 'rotate(180deg)' : 'none' }}
    aria-hidden="true"
  >
    <path
      d="M0,10 Q30,40 60,10 T120,10 T180,10 T240,10 T300,10 T360,10 T420,10 T480,10 T540,10 T600,10 T660,10 T720,10 T780,10 T840,10 T900,10 T960,10 T1020,10 T1080,10 T1140,10 T1200,10 L1200,0 L0,0 Z"
      fill={color}
    />
  </svg>
);

export default ScallopDivider;
