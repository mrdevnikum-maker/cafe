import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Gates a route behind login (and optionally a specific role, e.g. admin).
const ProtectedRoute = ({ children, requireAdmin = false }) => {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (requireAdmin && user.role !== 'admin') return <Navigate to="/" replace />;

  return children;
};

export default ProtectedRoute;
