import { Link } from 'react-router-dom';
import { FiMapPin, FiPhone, FiClock, FiInstagram, FiFacebook } from 'react-icons/fi';
import ScallopDivider from './ScallopDivider';
import './Footer.css';

const Footer = () => (
  <footer className="footer">
    <ScallopDivider color="var(--charcoal)" />
    <div className="container footer__inner">
      <div className="footer__col footer__brand">
        <span className="footer__logo">Alfredo Bistro</span>
        <p>Authentic Italian Cafe Experience — pizza, pasta, coffee and desserts, made the way Nonna intended.</p>
        <div className="footer__social">
          <a href="#" aria-label="Instagram"><FiInstagram size={18} /></a>
          <a href="#" aria-label="Facebook"><FiFacebook size={18} /></a>
        </div>
      </div>

      <div className="footer__col">
        <h4>Explore</h4>
        <Link to="/menu">Menu</Link>
        <Link to="/gallery">Gallery</Link>
        <Link to="/reviews">Reviews</Link>
        <Link to="/reservation">Reservation</Link>
        <Link to="/faq">FAQ</Link>
      </div>

      <div className="footer__col">
        <h4>Visit Us</h4>
        <p><FiMapPin size={15} /> 49/50 Opposite SRK MAX Hospital, Satya Vihar, Greater Kailash Colony, Vidhayak Nagar, Lalkothi, Jaipur, Rajasthan 302015</p>
        <p><FiPhone size={15} /> <a href="tel:8949139403">8949139403</a></p>
        <p><FiClock size={15} /> Open Daily, 10:00 AM – 11:00 PM</p>
      </div>

      <div className="footer__col">
        <h4>Legal</h4>
        <Link to="/privacy-policy">Privacy Policy</Link>
        <Link to="/terms">Terms & Conditions</Link>
      </div>
    </div>
    <div className="footer__bottom">
      <div className="container">© {new Date().getFullYear()} Alfredo Bistro. All rights reserved.</div>
    </div>
  </footer>
);

export default Footer;
