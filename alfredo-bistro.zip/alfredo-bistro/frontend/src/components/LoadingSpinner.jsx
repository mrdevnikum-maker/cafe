const LoadingSpinner = ({ label = 'Loading…' }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, padding: '64px 0' }}>
    <div
      style={{
        width: 34,
        height: 34,
        borderRadius: '50%',
        border: '3px solid rgba(190,90,44,0.2)',
        borderTopColor: 'var(--terracotta)',
        animation: 'spin 0.8s linear infinite',
      }}
    />
    <span style={{ fontSize: 14, color: 'var(--ink)', opacity: 0.6 }}>{label}</span>
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

export default LoadingSpinner;
