import { useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FiMenu, FiX, FiPhoneCall } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

const LINKS = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/menu', label: 'Menu' },
  { to: '/gallery', label: 'Gallery' },
  { to: '/reviews', label: 'Reviews' },
  { to: '/contact', label: 'Contact' },
];

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { user, logout } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`navbar ${scrolled ? 'navbar--scrolled' : ''}`}>
      <div className="container navbar__inner">
        <Link to="/" className="navbar__logo" onClick={() => setOpen(false)}>
          <span className="navbar__logo-script">Alfredo</span>
          <span className="navbar__logo-sub">BISTRO</span>
        </Link>

        <nav className={`navbar__links ${open ? 'navbar__links--open' : ''}`}>
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) => `navbar__link ${isActive ? 'navbar__link--active' : ''}`}
              onClick={() => setOpen(false)}
            >
              {l.label}
            </NavLink>
          ))}
          <div className="navbar__auth-mobile">
            {user ? (
              <>
                <Link to="/profile" onClick={() => setOpen(false)} className="navbar__link">Profile</Link>
                <button className="navbar__link" onClick={logout}>Log out</button>
              </>
            ) : (
              <Link to="/login" onClick={() => setOpen(false)} className="navbar__link">Login</Link>
            )}
          </div>
        </nav>

        <div className="navbar__actions">
          <a href="tel:8949139403" className="navbar__call">
            <FiPhoneCall size={16} />
            <span>8949139403</span>
          </a>
          {user ? (
            <Link to="/profile" className="btn btn-dark-outline navbar__profile-btn">Hi, {user.name?.split(' ')[0]}</Link>
          ) : (
            <Link to="/login" className="btn btn-dark-outline navbar__profile-btn">Login</Link>
          )}
          <Link to="/reservation" className="btn btn-primary">Reserve Table</Link>
        </div>

        <button className="navbar__burger" onClick={() => setOpen((o) => !o)} aria-label="Toggle menu">
          {open ? <FiX size={24} /> : <FiMenu size={24} />}
        </button>
      </div>
    </header>
  );
};

export default Navbar;
