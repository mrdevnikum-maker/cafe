import { useEffect, useState, useCallback } from 'react';

// Small generic data-fetching hook: pass an async function, get back
// { data, loading, error, refetch }. Keeps pages free of repeated
// try/catch/loading boilerplate.
export const useFetch = (fetcher, deps = []) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const run = useCallback(() => {
    setLoading(true);
    setError(null);
    fetcher()
      .then((res) => setData(res.data ?? res))
      .catch((err) => setError(err.response?.data?.message || 'Something went wrong'))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    run();
  }, [run]);

  return { data, loading, error, refetch: run };
};
