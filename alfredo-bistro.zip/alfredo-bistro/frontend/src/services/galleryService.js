import api from './api';

export const getGalleryImages = (category) =>
  api.get('/gallery', { params: category ? { category } : {} }).then((r) => r.data);
