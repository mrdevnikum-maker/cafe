import api from './api';

export const getCategories = () => api.get('/menu/categories').then((r) => r.data);
export const getFoodItems = (params) => api.get('/menu/items', { params }).then((r) => r.data);
export const getFoodItem = (id) => api.get(`/menu/items/${id}`).then((r) => r.data);
