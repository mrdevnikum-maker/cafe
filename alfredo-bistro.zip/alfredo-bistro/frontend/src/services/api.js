import axios from 'axios';

// Single axios instance for the whole app. Attaches the JWT automatically
// and redirects to /login if a token has expired or was rejected.
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('alfredo_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('alfredo_token');
      localStorage.removeItem('alfredo_user');
    }
    return Promise.reject(error);
  }
);

export default api;
