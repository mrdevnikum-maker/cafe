import api from './api';

export const createReservation = (payload) => api.post('/reservations', payload).then((r) => r.data);
export const getMyReservations = () => api.get('/users/reservations').then((r) => r.data);
