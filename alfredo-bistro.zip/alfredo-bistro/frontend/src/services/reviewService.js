import api from './api';

export const getReviews = () => api.get('/reviews').then((r) => r.data);
export const createReview = (payload) => api.post('/reviews', payload).then((r) => r.data);
