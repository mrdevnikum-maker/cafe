import api from './api';

export const submitContactForm = (payload) => api.post('/contact', payload).then((r) => r.data);
