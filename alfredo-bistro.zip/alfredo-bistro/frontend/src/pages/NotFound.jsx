import { Link } from 'react-router-dom';

const NotFound = () => (
  <div className="notfound">
    <span>404</span>
    <h2>This table isn't set.</h2>
    <p style={{ opacity: 0.7, maxWidth: 380 }}>The page you're looking for doesn't exist, or may have moved.</p>
    <Link to="/" className="btn btn-primary">Back to Home</Link>
  </div>
);

export default NotFound;
