import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiPhoneCall, FiCalendar, FiShoppingBag, FiHeart, FiClock, FiCoffee } from 'react-icons/fi';
import ScallopDivider from '../components/ScallopDivider';
import LoadingSpinner from '../components/LoadingSpinner';
import { useFetch } from '../hooks/useFetch';
import { getFoodItems } from '../services/menuService';
import { getReviews } from '../services/reviewService';

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.6, ease: 'easeOut' },
};

const Home = () => {
  const { data: popularItems } = useFetch(() => getFoodItems({ limit: 6, sort: '-ratingAverage' }), []);
  const { data: reviews } = useFetch(() => getReviews(), []);

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero__bg" />
        <div className="container hero__inner">
          <span className="eyebrow hero__eyebrow">Lalkothi, Jaipur</span>
          <h1>Authentic Italian, <em>served with warmth.</em></h1>
          <p className="hero__sub">
            Wood-fired pizza, slow-simmered pasta and full-bodied coffee in a room built for
            long, unhurried tables — dine in, takeaway, or no-contact delivery, every day 10am–11pm.
          </p>
          <div className="hero__actions">
            <a href="tel:8949139403" className="btn btn-gold"><FiPhoneCall /> Call Now</a>
            <Link to="/reservation" className="btn btn-primary"><FiCalendar /> Reserve a Table</Link>
            <Link to="/menu" className="btn btn-outline"><FiShoppingBag /> Order Online</Link>
          </div>
        </div>
        <ScallopDivider color="var(--paper)" className="hero__scallop" />
      </section>

      {/* ABOUT TEASER */}
      <section className="section">
        <div className="container story">
          <motion.div {...fadeUp} className="story__art">
            <img src="https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?q=80&w=900&auto=format&fit=crop" alt="Fresh pasta being prepared in the Alfredo Bistro kitchen" />
            <div className="story__badge"><strong>7+</strong><span>Signature Dishes</span></div>
          </motion.div>
          <motion.div {...fadeUp}>
            <span className="eyebrow">Our Story</span>
            <h2>A cafe built around the family table.</h2>
            <p>
              Alfredo Bistro began with a simple idea: Italian food doesn't need to be fussy to be
              excellent. Our kitchen leans on good olive oil, real Parmigiano, and dough that's
              rested overnight — the same way it's done in Rome's neighbourhood trattorias.
            </p>
            <p>
              Every table in our Lalkothi dining room is set for conversation, not just a quick meal —
              from the terracotta feature wall to the last cup of coffee.
            </p>
            <Link to="/about" className="btn btn-dark-outline">Read Our Full Story</Link>
          </motion.div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section" style={{ background: 'var(--cream)' }}>
        <div className="container">
          <motion.div {...fadeUp} className="section-head section-head--center">
            <span className="eyebrow">Why Choose Us</span>
            <h2>What makes a table at Alfredo different</h2>
          </motion.div>
          <div className="why-grid">
            {[
              { icon: <FiCoffee />, title: 'Small-Batch Coffee', text: 'Beans roasted for us in small batches, pulled fresh cup by cup.' },
              { icon: <FiHeart />, title: 'Made to Order', text: 'Nothing sits under a heat lamp — every plate starts when you order it.' },
              { icon: <FiClock />, title: 'Open All Day', text: '10am to 11pm, every day — for breakfast espresso or a late dinner.' },
            ].map((f, i) => (
              <motion.div key={f.title} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.08 }} className="why-card">
                <div className="icon-wrap">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* MENU HIGHLIGHTS */}
      <section className="section">
        <div className="container">
          <motion.div {...fadeUp} className="section-head" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 16 }}>
            <div>
              <span className="eyebrow">From the Kitchen</span>
              <h2>Guest favourites</h2>
            </div>
            <Link to="/menu" className="btn btn-dark-outline">View Full Menu</Link>
          </motion.div>

          {!popularItems ? (
            <LoadingSpinner label="Plating up the menu…" />
          ) : popularItems.length === 0 ? (
            <p className="empty-state">Menu items will appear here once added from the admin panel.</p>
          ) : (
            <div className="menu-grid">
              {popularItems.map((item, i) => (
                <motion.div key={item._id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.06 }} className="card menu-card">
                  <div className="menu-card__img-wrap">
                    <img src={item.image || 'https://images.unsplash.com/photo-1595854341625-f33ee10dbf94?q=80&w=600&auto=format&fit=crop'} alt={item.name} />
                    {item.isPopular && <span className="menu-card__badge">Popular</span>}
                  </div>
                  <div className="menu-card__body">
                    <div className="menu-card__top">
                      <h3>{item.name}</h3>
                      <span className="menu-card__price">₹{item.price}</span>
                    </div>
                    <p>{item.description}</p>
                    <span className="menu-card__veg"><span className={`veg-dot ${!item.isVeg ? 'veg-dot--non' : ''}`} /> {item.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section" style={{ background: 'var(--charcoal)', color: 'var(--paper)' }}>
        <div className="container">
          <motion.div {...fadeUp} className="section-head section-head--center">
            <span className="eyebrow" style={{ color: 'var(--gold-soft)' }}>What Guests Say</span>
            <h2 style={{ color: 'var(--paper)' }}>Loved by the neighbourhood</h2>
          </motion.div>
          {!reviews ? (
            <LoadingSpinner label="Gathering reviews…" />
          ) : (
            <div className="review-grid">
              {(reviews.slice(0, 3)).map((r, i) => (
                <motion.div key={r._id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.08 }} className="glass card review-card" style={{ color: 'var(--paper)' }}>
                  <div className="review-card__stars">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</div>
                  <p className="comment">"{r.comment}"</p>
                  <div className="review-card__author">
                    <div className="review-card__avatar">{r.user?.name?.[0] || 'G'}</div>
                    <div>
                      <strong>{r.user?.name || 'Guest'}</strong>
                      <span style={{ opacity: 0.6 }}>Verified Diner</span>
                    </div>
                  </div>
                </motion.div>
              ))}
              {reviews.length === 0 && <p className="empty-state" style={{ color: 'var(--paper)', opacity: 0.6, gridColumn: '1/-1' }}>Reviews will appear here once guests start sharing feedback.</p>}
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default Home;
