const PrivacyPolicy = () => (
  <div className="static-page">
    <h1>Privacy Policy</h1>
    <p>Last updated: {new Date().getFullYear()}</p>
    <p>Alfredo Bistro ("we", "us") respects your privacy. This page explains what information we collect through this website and how it's used.</p>
    <h2>Information We Collect</h2>
    <p>Name, email, and phone number when you register, make a reservation, place an order, or contact us. We do not sell this information to third parties.</p>
    <h2>How We Use It</h2>
    <ul>
      <li>To process reservations and orders</li>
      <li>To send confirmation emails and, if you opt in, newsletters</li>
      <li>To respond to enquiries submitted via the Contact form</li>
    </ul>
    <h2>Data Security</h2>
    <p>Passwords are hashed and never stored in plain text. Access to admin data is protected by role-based authentication.</p>
    <h2>Contact</h2>
    <p>Questions about this policy can be sent through our Contact page.</p>
  </div>
);

export default PrivacyPolicy;
