const Terms = () => (
  <div className="static-page">
    <h1>Terms & Conditions</h1>
    <p>Last updated: {new Date().getFullYear()}</p>
    <h2>Reservations</h2>
    <p>Tables are held for 15 minutes past the reserved time. Cancellations can be made by contacting us directly.</p>
    <h2>Orders</h2>
    <p>Prices are listed in INR and may change without prior notice. All orders are subject to availability.</p>
    <h2>Reviews</h2>
    <p>Reviews are moderated before appearing publicly and should reflect genuine dining experiences.</p>
    <h2>Liability</h2>
    <p>Alfredo Bistro is not liable for allergic reactions where allergies were not disclosed at the time of ordering.</p>
  </div>
);

export default Terms;
