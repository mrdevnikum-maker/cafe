import { useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { forgotPassword } from '../services/authService';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await forgotPassword(email);
      setSent(true);
    } catch (err) {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="split-page">
      <div className="split-page__visual">
        <div className="split-page__visual-content">
          <span className="eyebrow" style={{ color: 'var(--gold-soft)' }}>Account Recovery</span>
          <h2 style={{ color: 'var(--paper)', margin: '16px 0' }}>Let's get you back in.</h2>
        </div>
      </div>
      <div className="split-page__form">
        <div className="split-page__form-inner">
          <h2 style={{ marginBottom: 16 }}>Reset Password</h2>
          {sent ? (
            <p style={{ opacity: 0.75 }}>If that email exists in our system, a reset link is on its way. Check your inbox.</p>
          ) : (
            <form onSubmit={handleSubmit}>
              <p style={{ opacity: 0.7, marginBottom: 20, fontSize: 14.5 }}>Enter your account email and we'll send a link to reset your password.</p>
              <div className="field" style={{ marginBottom: 20 }}>
                <label htmlFor="email">Email</label>
                <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <button className="btn btn-primary" style={{ width: '100%' }} type="submit" disabled={submitting}>{submitting ? 'Sending…' : 'Send Reset Link'}</button>
            </form>
          )}
          <p className="auth-switch"><Link to="/login">Back to Login</Link></p>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
