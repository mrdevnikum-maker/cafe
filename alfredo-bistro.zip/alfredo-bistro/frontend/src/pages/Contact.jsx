import { useState } from 'react';
import toast from 'react-hot-toast';
import { FiMapPin, FiPhone, FiClock, FiMail } from 'react-icons/fi';
import { submitContactForm } from '../services/contactService';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await submitContactForm(form);
      toast.success(res.message || 'Message sent!');
      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not send message');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container">
        <div className="section-head section-head--center">
          <span className="eyebrow">Get In Touch</span>
          <h2>Visit us or drop a message</h2>
        </div>

        <div className="contact-grid">
          <div className="contact-info-card card">
            <div className="contact-info-row">
              <div className="icon-wrap"><FiMapPin size={18} /></div>
              <div>
                <h4>Address</h4>
                <p>49/50 Opposite SRK MAX Hospital, Satya Vihar, Greater Kailash Colony, Vidhayak Nagar, Lalkothi, Jaipur, Rajasthan 302015</p>
              </div>
            </div>
            <div className="contact-info-row">
              <div className="icon-wrap"><FiPhone size={18} /></div>
              <div>
                <h4>Phone</h4>
                <a href="tel:8949139403">8949139403</a>
              </div>
            </div>
            <div className="contact-info-row">
              <div className="icon-wrap"><FiClock size={18} /></div>
              <div>
                <h4>Opening Hours</h4>
                <p>Open Daily, 10:00 AM – 11:00 PM</p>
              </div>
            </div>
            <div className="contact-info-row">
              <div className="icon-wrap"><FiMail size={18} /></div>
              <div>
                <h4>Email</h4>
                <p>hello@alfredobistro.com</p>
              </div>
            </div>
            <iframe
              className="map-embed"
              title="Alfredo Bistro location"
              loading="lazy"
              src="https://www.google.com/maps?q=Lalkothi,Jaipur,Rajasthan&output=embed"
            />
          </div>

          <form className="card form-card" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="field">
                <label htmlFor="c-name">Name</label>
                <input id="c-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="field">
                <label htmlFor="c-phone">Phone</label>
                <input id="c-phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
            </div>
            <div className="field">
              <label htmlFor="c-email">Email</label>
              <input id="c-email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="field">
              <label htmlFor="c-subject">Subject</label>
              <input id="c-subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="Reservation query, feedback, etc." />
            </div>
            <div className="field">
              <label htmlFor="c-message">Message</label>
              <textarea id="c-message" rows={5} required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            </div>
            <button className="btn btn-primary" type="submit" disabled={submitting}>{submitting ? 'Sending…' : 'Send Message'}</button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
