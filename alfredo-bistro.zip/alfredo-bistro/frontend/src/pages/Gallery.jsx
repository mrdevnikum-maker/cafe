import { useState } from 'react';
import { FiX } from 'react-icons/fi';
import { useFetch } from '../hooks/useFetch';
import { getGalleryImages } from '../services/galleryService';
import LoadingSpinner from '../components/LoadingSpinner';

const FALLBACK = [
  'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1544148103-0773bf10d330?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1595854341625-f33ee10dbf94?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1595295333158-4742f28fbd85?q=80&w=800&auto=format&fit=crop',
];

const Gallery = () => {
  const { data: images, loading } = useFetch(() => getGalleryImages(), []);
  const [lightbox, setLightbox] = useState(null);

  const list = images && images.length > 0 ? images.map((i) => i.image) : FALLBACK;

  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container">
        <div className="section-head section-head--center">
          <span className="eyebrow">Gallery</span>
          <h2>A look inside Alfredo Bistro</h2>
        </div>

        {loading ? (
          <LoadingSpinner label="Loading photos…" />
        ) : (
          <div className="gallery-grid">
            {list.map((src, i) => (
              <div key={i} className="gallery-item" onClick={() => setLightbox(src)}>
                <img src={src} alt={`Alfredo Bistro gallery ${i + 1}`} loading="lazy" />
              </div>
            ))}
          </div>
        )}
        {(!images || images.length === 0) && !loading && (
          <p className="empty-state">Showing sample photos — real gallery images will replace these once uploaded via the admin panel.</p>
        )}
      </div>

      {lightbox && (
        <div className="lightbox-backdrop" onClick={() => setLightbox(null)}>
          <button className="lightbox-close" onClick={() => setLightbox(null)} aria-label="Close"><FiX size={28} /></button>
          <img src={lightbox} alt="Enlarged gallery" className="lightbox-img" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </section>
  );
};

export default Gallery;
