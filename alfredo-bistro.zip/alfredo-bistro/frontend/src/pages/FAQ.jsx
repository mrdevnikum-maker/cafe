import { useState } from 'react';
import { FiChevronDown, FiChevronUp } from 'react-icons/fi';

const FAQS = [
  { q: 'Do you take walk-ins or only reservations?', a: 'Both! Reservations are recommended for weekend evenings and groups of 5+, but we always hold a few walk-in tables.' },
  { q: 'Is outside catering or event booking available?', a: 'Yes, reach out via the Contact page with your event date and headcount and our team will get back to you.' },
  { q: 'Do you offer no-contact delivery?', a: 'Yes — dine-in, takeaway, kerbside pickup, and no-contact delivery are all available, daily 10am–11pm.' },
  { q: 'Are vegetarian and vegan options available?', a: 'Most of our pasta, pizza and garlic bread come in vegetarian versions, clearly marked on the menu.' },
  { q: 'What is the average cost for two people?', a: 'Most guests spend around ₹200–₹400 per person, depending on what you order.' },
];

const FAQ = () => {
  const [open, setOpen] = useState(0);
  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container" style={{ maxWidth: 720 }}>
        <div className="section-head section-head--center">
          <span className="eyebrow">FAQ</span>
          <h2>Common questions</h2>
        </div>
        {FAQS.map((f, i) => (
          <div key={f.q} className="faq-item">
            <button onClick={() => setOpen(open === i ? -1 : i)}>
              {f.q} {open === i ? <FiChevronUp /> : <FiChevronDown />}
            </button>
            {open === i && <p>{f.a}</p>}
          </div>
        ))}
      </div>
    </section>
  );
};

export default FAQ;
