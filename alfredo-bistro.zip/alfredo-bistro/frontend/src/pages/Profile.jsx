import { useState } from 'react';
import { FiUser, FiShoppingBag, FiCalendar, FiHeart, FiLogOut } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import { useFetch } from '../hooks/useFetch';
import { getMyReservations } from '../services/reservationService';
import api from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';

const TABS = [
  { key: 'overview', label: 'Overview', icon: <FiUser /> },
  { key: 'orders', label: 'Order History', icon: <FiShoppingBag /> },
  { key: 'reservations', label: 'Reservations', icon: <FiCalendar /> },
  { key: 'wishlist', label: 'Wishlist', icon: <FiHeart /> },
];

const Profile = () => {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('overview');

  const { data: reservations, loading: loadingRes } = useFetch(() => getMyReservations(), []);
  const { data: orders, loading: loadingOrders } = useFetch(() => api.get('/users/orders').then((r) => r.data), []);
  const { data: wishlist, loading: loadingWishlist } = useFetch(() => api.get('/users/wishlist').then((r) => r.data), []);

  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container profile-shell">
        <aside className="profile-nav">
          <div style={{ marginBottom: 20 }}>
            <h3 style={{ fontSize: 20 }}>{user?.name}</h3>
            <p style={{ fontSize: 13.5, opacity: 0.6 }}>{user?.email}</p>
          </div>
          {TABS.map((t) => (
            <button key={t.key} className={tab === t.key ? 'active' : ''} onClick={() => setTab(t.key)}>
              {t.icon} &nbsp;{t.label}
            </button>
          ))}
          <button onClick={logout} style={{ color: 'var(--terracotta-deep)' }}><FiLogOut /> &nbsp;Log Out</button>
        </aside>

        <div className="profile-card card">
          {tab === 'overview' && (
            <div>
              <h3>Welcome back, {user?.name?.split(' ')[0]}</h3>
              <p style={{ opacity: 0.7, marginTop: 8 }}>Manage your orders, reservations, and favourite dishes from this page.</p>
            </div>
          )}

          {tab === 'orders' && (
            loadingOrders ? <LoadingSpinner /> : !orders || orders.length === 0 ? (
              <p className="empty-state">No orders yet — your order history will show up here.</p>
            ) : orders.map((o) => (
              <div key={o._id} className="order-row">
                <span>{o.items.length} item(s) · ₹{o.totalAmount}</span>
                <span className="status-pill">{o.orderStatus}</span>
              </div>
            ))
          )}

          {tab === 'reservations' && (
            loadingRes ? <LoadingSpinner /> : !reservations || reservations.length === 0 ? (
              <p className="empty-state">No reservations yet — book a table to see it here.</p>
            ) : reservations.map((r) => (
              <div key={r._id} className="res-row">
                <span>{new Date(r.date).toLocaleDateString()} at {r.time} · {r.guests} guests</span>
                <span className="status-pill">{r.status}</span>
              </div>
            ))
          )}

          {tab === 'wishlist' && (
            loadingWishlist ? <LoadingSpinner /> : !wishlist || wishlist.length === 0 ? (
              <p className="empty-state">Tap the heart on any dish to save it here.</p>
            ) : (
              <div className="menu-grid">
                {wishlist.map((item) => (
                  <div key={item._id} className="card menu-card">
                    <div className="menu-card__img-wrap"><img src={item.image} alt={item.name} /></div>
                    <div className="menu-card__body">
                      <div className="menu-card__top"><h3>{item.name}</h3><span className="menu-card__price">₹{item.price}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
};

export default Profile;
