import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="split-page">
      <div className="split-page__visual">
        <div className="split-page__visual-content">
          <span className="eyebrow" style={{ color: 'var(--gold-soft)' }}>Welcome Back</span>
          <h2 style={{ color: 'var(--paper)', margin: '16px 0' }}>Your table's always ready.</h2>
          <p style={{ opacity: 0.8 }}>Log in to track orders, manage reservations, and keep your favourite dishes close.</p>
        </div>
      </div>
      <div className="split-page__form">
        <form className="split-page__form-inner" onSubmit={handleSubmit}>
          <h2 style={{ marginBottom: 24 }}>Log In</h2>
          <div className="field" style={{ marginBottom: 16 }}>
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 8 }}>
            <label htmlFor="password">Password</label>
            <input id="password" type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          <div style={{ textAlign: 'right', marginBottom: 20 }}>
            <Link to="/forgot-password" style={{ fontSize: 13.5, color: 'var(--terracotta-deep)', fontWeight: 600 }}>Forgot password?</Link>
          </div>
          <button className="btn btn-primary" style={{ width: '100%' }} type="submit" disabled={submitting}>{submitting ? 'Logging in…' : 'Log In'}</button>
          <p className="auth-switch">New here? <Link to="/register">Create an account</Link></p>
        </form>
      </div>
    </div>
  );
};

export default Login;
