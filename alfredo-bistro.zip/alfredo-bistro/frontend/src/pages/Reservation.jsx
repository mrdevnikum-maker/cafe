import { useState } from 'react';
import toast from 'react-hot-toast';
import { createReservation } from '../services/reservationService';
import { useAuth } from '../context/AuthContext';

const initialForm = { name: '', email: '', phone: '', date: '', time: '', guests: 2, specialRequest: '' };

const Reservation = () => {
  const { user } = useAuth();
  const [form, setForm] = useState({ ...initialForm, name: user?.name || '', email: user?.email || '' });
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = 'Name is required';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = 'Valid email is required';
    if (!form.phone.trim()) errs.phone = 'Phone number is required';
    if (!form.date) errs.date = 'Please choose a date';
    if (!form.time) errs.time = 'Please choose a time';
    if (form.guests < 1) errs.guests = 'At least 1 guest';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      await createReservation(form);
      toast.success("Table reserved! We've sent a confirmation to your email.");
      setForm(initialForm);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not create reservation');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container" style={{ display: 'flex', justifyContent: 'center' }}>
        <div style={{ maxWidth: 620, width: '100%' }}>
          <div className="section-head section-head--center">
            <span className="eyebrow">Book a Table</span>
            <h2>Reserve your evening</h2>
          </div>
          <form className="card form-card" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="field">
                <label htmlFor="name">Full Name</label>
                <input id="name" name="name" value={form.name} onChange={handleChange} placeholder="Your name" />
                {errors.name && <span className="field-error">{errors.name}</span>}
              </div>
              <div className="field">
                <label htmlFor="phone">Phone Number</label>
                <input id="phone" name="phone" value={form.phone} onChange={handleChange} placeholder="98XXXXXXXX" />
                {errors.phone && <span className="field-error">{errors.phone}</span>}
              </div>
            </div>
            <div className="field">
              <label htmlFor="email">Email</label>
              <input id="email" type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com" />
              {errors.email && <span className="field-error">{errors.email}</span>}
            </div>
            <div className="form-row">
              <div className="field">
                <label htmlFor="date">Date</label>
                <input id="date" type="date" name="date" value={form.date} onChange={handleChange} min={new Date().toISOString().split('T')[0]} />
                {errors.date && <span className="field-error">{errors.date}</span>}
              </div>
              <div className="field">
                <label htmlFor="time">Time</label>
                <input id="time" type="time" name="time" value={form.time} onChange={handleChange} />
                {errors.time && <span className="field-error">{errors.time}</span>}
              </div>
            </div>
            <div className="field">
              <label htmlFor="guests">Number of Guests</label>
              <input id="guests" type="number" min={1} max={20} name="guests" value={form.guests} onChange={handleChange} />
              {errors.guests && <span className="field-error">{errors.guests}</span>}
            </div>
            <div className="field">
              <label htmlFor="specialRequest">Special Request (optional)</label>
              <textarea id="specialRequest" name="specialRequest" rows={3} value={form.specialRequest} onChange={handleChange} placeholder="Window seat, birthday, allergies…" />
            </div>
            <button className="btn btn-primary" type="submit" disabled={submitting}>{submitting ? 'Booking…' : 'Confirm Reservation'}</button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Reservation;
