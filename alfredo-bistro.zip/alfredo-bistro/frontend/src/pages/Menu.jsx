import { useState } from 'react';
import { FiSearch } from 'react-icons/fi';
import { useFetch } from '../hooks/useFetch';
import { getCategories, getFoodItems } from '../services/menuService';
import LoadingSpinner from '../components/LoadingSpinner';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data: categories } = useFetch(() => getCategories(), []);
  const { data: itemsRes, loading } = useFetch(
    () => getFoodItems({ category: activeCategory || undefined, search: search || undefined, page }),
    [activeCategory, search, page]
  );

  const items = itemsRes?.data ?? itemsRes;
  const pages = itemsRes?.pages || 1;

  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container">
        <div className="section-head section-head--center">
          <span className="eyebrow">Our Menu</span>
          <h2>Pizza, pasta, coffee & more</h2>
        </div>

        <div className="menu-toolbar">
          <div className="menu-search">
            <FiSearch size={16} style={{ opacity: 0.5 }} />
            <input
              placeholder="Search the menu…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>
          <div className="menu-tabs">
            <button className={`menu-tab ${!activeCategory ? 'menu-tab--active' : ''}`} onClick={() => { setActiveCategory(''); setPage(1); }}>All</button>
            {categories?.map((c) => (
              <button
                key={c._id}
                className={`menu-tab ${activeCategory === c._id ? 'menu-tab--active' : ''}`}
                onClick={() => { setActiveCategory(c._id); setPage(1); }}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <LoadingSpinner label="Setting the table…" />
        ) : !items || items.length === 0 ? (
          <p className="empty-state">
            No dishes match yet — once menu items are added via the admin panel, they'll show up here, filterable and searchable.
          </p>
        ) : (
          <>
            <div className="menu-grid">
              {items.map((item) => (
                <div key={item._id} className="card menu-card">
                  <div className="menu-card__img-wrap">
                    <img src={item.image || 'https://images.unsplash.com/photo-1595854341625-f33ee10dbf94?q=80&w=600&auto=format&fit=crop'} alt={item.name} />
                    {item.isPopular && <span className="menu-card__badge">Popular</span>}
                  </div>
                  <div className="menu-card__body">
                    <div className="menu-card__top">
                      <h3>{item.name}</h3>
                      <span className="menu-card__price">₹{item.price}</span>
                    </div>
                    <p>{item.description}</p>
                    <span className="menu-card__veg"><span className={`veg-dot ${!item.isVeg ? 'veg-dot--non' : ''}`} /> {item.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}</span>
                  </div>
                </div>
              ))}
            </div>
            {pages > 1 && (
              <div className="pagination">
                {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
                  <button key={p} className={p === page ? 'active' : ''} onClick={() => setPage(p)}>{p}</button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
};

export default Menu;
