import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await register(form);
      toast.success('Account created! Welcome to Alfredo Bistro.');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="split-page">
      <div className="split-page__visual">
        <div className="split-page__visual-content">
          <span className="eyebrow" style={{ color: 'var(--gold-soft)' }}>Join Us</span>
          <h2 style={{ color: 'var(--paper)', margin: '16px 0' }}>Create your Alfredo account.</h2>
          <p style={{ opacity: 0.8 }}>Faster reservations, saved favourites, and order history in one place.</p>
        </div>
      </div>
      <div className="split-page__form">
        <form className="split-page__form-inner" onSubmit={handleSubmit}>
          <h2 style={{ marginBottom: 24 }}>Create Account</h2>
          <div className="field" style={{ marginBottom: 16 }}>
            <label htmlFor="name">Full Name</label>
            <input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 16 }}>
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 16 }}>
            <label htmlFor="phone">Phone</label>
            <input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 20 }}>
            <label htmlFor="password">Password</label>
            <input id="password" type="password" required minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          <button className="btn btn-primary" style={{ width: '100%' }} type="submit" disabled={submitting}>{submitting ? 'Creating…' : 'Create Account'}</button>
          <p className="auth-switch">Already have an account? <Link to="/login">Log in</Link></p>
        </form>
      </div>
    </div>
  );
};

export default Register;
