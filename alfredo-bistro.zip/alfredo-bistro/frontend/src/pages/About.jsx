import { motion } from 'framer-motion';
import { FiAward, FiUsers, FiFeather } from 'react-icons/fi';
import ScallopDivider from '../components/ScallopDivider';

const fadeUp = { initial: { opacity: 0, y: 24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

const About = () => (
  <>
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container story">
        <motion.div {...fadeUp} className="story__art">
          <img src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=900&auto=format&fit=crop" alt="Alfredo Bistro dining room" />
          <div className="story__badge"><strong>2019</strong><span>Est. in Jaipur</span></div>
        </motion.div>
        <motion.div {...fadeUp}>
          <span className="eyebrow">Our Story</span>
          <h2>Italy's kitchen table, brought to Lalkothi.</h2>
          <p>
            Alfredo Bistro opened with one goal — bring the unhurried, ingredient-first spirit of an
            Italian trattoria to Jaipur. No shortcuts on dough, no shortcuts on sauce, and a room
            designed to make you want to linger over the last of the coffee.
          </p>
          <p>
            The name is a small tribute to the classics: simple technique, honest ingredients, and
            recipes that don't need reinventing, only respecting.
          </p>
        </motion.div>
      </div>
    </section>

    <ScallopDivider color="var(--cream)" />

    <section className="section" style={{ background: 'var(--cream)' }}>
      <div className="container">
        <motion.div {...fadeUp} className="section-head section-head--center">
          <span className="eyebrow">Our Mission</span>
          <h2>Food that earns a second visit</h2>
        </motion.div>
        <div className="why-grid">
          {[
            { icon: <FiFeather />, title: 'Ingredient-First', text: 'We build every dish around what\'s fresh that morning, not around a fixed script.' },
            { icon: <FiAward />, title: 'Old-World Technique', text: 'Dough rested overnight, sauces built slow — no shortcuts that change the taste.' },
            { icon: <FiUsers />, title: 'A Room for Everyone', text: 'Families, first dates, solo espresso drinkers — the table is set the same way for all of them.' },
          ].map((f) => (
            <div key={f.title} className="why-card">
              <div className="icon-wrap">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container story">
        <motion.div {...fadeUp}>
          <span className="eyebrow">The Italian Experience</span>
          <h2>More trattoria, less formality.</h2>
          <p>
            Long tables for sharing, a menu built around pizza, pasta, coffee and dessert, and
            service that lets a meal run as long as the conversation needs. That's the whole
            playbook — borrowed straight from the neighbourhood spots we love most.
          </p>
          <p>Open daily, 10:00 AM – 11:00 PM, for dine-in, takeaway, kerbside pickup, or no-contact delivery.</p>
        </motion.div>
        <motion.div {...fadeUp} className="story__art">
          <img src="https://images.unsplash.com/photo-1544148103-0773bf10d330?q=80&w=900&auto=format&fit=crop" alt="Wood-fired pizza at Alfredo Bistro" />
        </motion.div>
      </div>
    </section>
  </>
);

export default About;
