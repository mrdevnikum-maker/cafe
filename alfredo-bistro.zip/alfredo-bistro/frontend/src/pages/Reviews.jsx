import { useState } from 'react';
import toast from 'react-hot-toast';
import { FiStar } from 'react-icons/fi';
import { useFetch } from '../hooks/useFetch';
import { getReviews, createReview } from '../services/reviewService';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';

const Reviews = () => {
  const { data: reviews, loading, refetch } = useFetch(() => getReviews(), []);
  const { user } = useAuth();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const avg = reviews && reviews.length > 0 ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return toast.error('Please log in to leave a review');
    setSubmitting(true);
    try {
      await createReview({ rating, comment });
      toast.success('Thanks! Your review is pending moderation.');
      setComment('');
      refetch();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not submit review');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="section" style={{ paddingTop: 64 }}>
      <div className="container">
        <div className="section-head section-head--center">
          <span className="eyebrow">Customer Reviews</span>
          <h2>Google-style ratings from our guests</h2>
        </div>

        {avg && (
          <div className="rating-banner">
            <span className="rating-banner__score">{avg}</span>
            <div>
              <div className="rating-banner__stars">{'★'.repeat(Math.round(avg))}{'☆'.repeat(5 - Math.round(avg))}</div>
              <span style={{ fontSize: 13.5, opacity: 0.65 }}>Based on {reviews.length} verified reviews</span>
            </div>
          </div>
        )}

        {loading ? (
          <LoadingSpinner />
        ) : !reviews || reviews.length === 0 ? (
          <p className="empty-state">No reviews yet — be the first to share your experience below.</p>
        ) : (
          <div className="review-grid">
            {reviews.map((r) => (
              <div key={r._id} className="card review-card">
                <div className="review-card__stars">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</div>
                <p className="comment">"{r.comment}"</p>
                <div className="review-card__author">
                  <div className="review-card__avatar">{r.user?.name?.[0] || 'G'}</div>
                  <div>
                    <strong>{r.user?.name || 'Guest'}</strong>
                    <span>Verified Diner</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <form className="card review-form" onSubmit={handleSubmit}>
          <h3 style={{ fontSize: 20 }}>Leave a Review</h3>
          <div className="field">
            <label>Your Rating</label>
            <div style={{ display: 'flex', gap: 6 }}>
              {[1, 2, 3, 4, 5].map((n) => (
                <button type="button" key={n} onClick={() => setRating(n)} style={{ background: 'none', border: 'none', color: n <= rating ? 'var(--gold)' : '#ddd' }}>
                  <FiStar size={22} fill={n <= rating ? 'var(--gold)' : 'none'} />
                </button>
              ))}
            </div>
          </div>
          <div className="field">
            <label htmlFor="comment">Your Experience</label>
            <textarea id="comment" rows={4} required value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Tell other guests what stood out…" />
          </div>
          <button className="btn btn-primary" type="submit" disabled={submitting}>{submitting ? 'Submitting…' : 'Submit Review'}</button>
          {!user && <span style={{ fontSize: 13, opacity: 0.6 }}>You'll need to log in first to submit a review.</span>}
        </form>
      </div>
    </section>
  );
};

export default Reviews;
