import { Outlet } from 'react-router-dom';
import Navbar from '../components/Navbar.jsx';
import Footer from '../components/Footer.jsx';

// Shared shell for every public/user-facing page: sticky nav + footer,
// with the routed page rendered in between via <Outlet />.
const MainLayout = () => (
  <>
    <Navbar />
    <main style={{ paddingTop: 'var(--nav-height)' }}>
      <Outlet />
    </main>
    <Footer />
  </>
);

export default MainLayout;
