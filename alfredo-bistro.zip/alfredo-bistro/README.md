# Alfredo Bistro — Full Stack Restaurant Website

Authentic Italian cafe website for **Alfredo Bistro** (Lalkothi, Jaipur), built with React + Vite on the
frontend and Node.js/Express/MongoDB on the backend.

This is **Phase 1 + 2** of the full build: a complete, working backend API and a fully responsive
public website with real user authentication. The **Admin Panel (Phase 3)** — dashboard analytics,
menu/gallery/blog/coupon/newsletter management, role-based settings — builds directly on top of the
models and controllers already in this codebase and is the next milestone.

## What's included right now

**Backend (`/backend`)**
- Express REST API, MongoDB via Mongoose
- Models: User, FoodCategory, FoodItem, Reservation, Order, Review, Gallery, Contact
- JWT authentication (register/login/me/forgot-password/reset-password), bcrypt password hashing
- Role-based middleware (`protect`, `authorize('admin')`) — admin-only routes are already wired for
  menu, gallery, reservations, orders and reviews, ready for the admin UI to call
- Multer image uploads, Nodemailer email (reservation confirmations, contact notifications, password reset)
- Security: Helmet, CORS, rate limiting, mongo-sanitize, express-validator
- Centralized error handling

**Frontend (`/frontend`)**
- React + Vite + React Router, Axios, Framer Motion, React Icons, react-hot-toast
- Public pages: Home, About, Menu (search/filter/pagination), Gallery (lightbox), Reviews
  (list + submit), Reservation, Contact (with map embed), FAQ, Privacy Policy, Terms, 404
- Auth pages: Login, Register, Forgot Password; Profile page with Orders / Reservations / Wishlist tabs
- Design system in `src/styles/tokens.css` — palette and signature scalloped divider drawn from the
  restaurant's actual interior (terracotta feature wall, teal dining chairs, gold pendant lights)

## Getting started

### 1. Backend
```bash
cd backend
cp .env.example .env      # fill in MONGO_URI, JWT_SECRET, SMTP credentials
npm install
npm run seed               # creates the default admin user from .env
npm run dev                 # http://localhost:5000
```

### 2. Frontend
```bash
cd frontend
cp .env.example .env
npm install
npm run dev                 # http://localhost:5173
```

The Vite dev server proxies `/api` and `/uploads` to `http://localhost:5000`, so no CORS
configuration is needed locally beyond what's already in `server.js`.

### Default admin login
```
Email:    admin@alfredobistro.com
Password: Admin@123
```
(Seeded by `npm run seed` from the values in `backend/.env`.)

## API overview

| Resource | Base route | Notes |
|---|---|---|
| Auth | `/api/auth` | register, login, me, forgot/reset password |
| Users | `/api/users` | profile, my orders, my reservations, wishlist |
| Menu | `/api/menu` | categories + items, public GET, admin-only write |
| Reservations | `/api/reservations` | public POST, admin-only list/update/delete |
| Orders | `/api/orders` | user POST, admin-only list/update |
| Reviews | `/api/reviews` | public GET, user POST, admin-only approve/delete |
| Gallery | `/api/gallery` | public GET, admin-only add/delete |
| Contact | `/api/contact` | public POST, admin-only list/mark-read |

## Production deployment (short version)

1. **Database**: provision MongoDB Atlas (or self-hosted), set `MONGO_URI`.
2. **Backend**: deploy to Render/Railway/EC2. Set all `.env` values (strong `JWT_SECRET`, real SMTP
   credentials). Point uploads at persistent storage or swap `middleware/upload.js` to S3/Cloudinary.
3. **Frontend**: `npm run build` → deploy the `dist/` folder to Vercel/Netlify, or serve it from Express.
   Set `VITE_API_URL` to your deployed API URL.
4. Put both behind HTTPS; update `CLIENT_URL`/CORS accordingly.

## Next milestone — Phase 3 (Admin Panel)

- Admin dashboard (orders, reservations, revenue, visitors, popular dishes) with charts
- Full CRUD screens for menu, gallery, blog, testimonials, coupons, offers
- Newsletter subscriber list, contact message inbox, website/SEO settings, logo/favicon upload
- Blog model + public blog pages, Coupon model wired into checkout, Newsletter model + signup

