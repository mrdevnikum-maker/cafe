const asyncHandler = require('../utils/asyncHandler');
const User = require('../models/User');
const Reservation = require('../models/Reservation');
const Order = require('../models/Order');

// @route  PUT /api/users/profile
// @access Private
const updateProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });

  user.name = req.body.name || user.name;
  user.phone = req.body.phone || user.phone;
  user.newsletterSubscribed = req.body.newsletterSubscribed ?? user.newsletterSubscribed;
  await user.save();

  res.json({ success: true, data: user });
});

// @route  GET /api/users/orders
// @access Private
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort('-createdAt');
  res.json({ success: true, count: orders.length, data: orders });
});

// @route  GET /api/users/reservations
// @access Private
const getMyReservations = asyncHandler(async (req, res) => {
  const reservations = await Reservation.find({ user: req.user._id }).sort('-createdAt');
  res.json({ success: true, count: reservations.length, data: reservations });
});

// @route  POST /api/users/wishlist/:foodItemId
// @access Private
const toggleWishlist = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const { foodItemId } = req.params;

  const index = user.wishlist.findIndex((id) => id.toString() === foodItemId);
  if (index > -1) {
    user.wishlist.splice(index, 1);
  } else {
    user.wishlist.push(foodItemId);
  }
  await user.save();

  res.json({ success: true, data: user.wishlist });
});

// @route  GET /api/users/wishlist
// @access Private
const getWishlist = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate('wishlist');
  res.json({ success: true, data: user.wishlist });
});

module.exports = { updateProfile, getMyOrders, getMyReservations, toggleWishlist, getWishlist };
