const asyncHandler = require('../utils/asyncHandler');
const Reservation = require('../models/Reservation');
const sendEmail = require('../utils/sendEmail');

// @route  POST /api/reservations
// @access Public (works for guests and logged-in users)
const createReservation = asyncHandler(async (req, res) => {
  const { name, email, phone, date, time, guests, specialRequest } = req.body;

  const reservation = await Reservation.create({
    user: req.user ? req.user._id : undefined,
    name,
    email,
    phone,
    date,
    time,
    guests,
    specialRequest,
  });

  // Best-effort confirmation email; a failed send shouldn't fail the booking.
  try {
    await sendEmail({
      to: email,
      subject: 'Alfredo Bistro - Reservation Received',
      html: `<p>Hi ${name},</p>
             <p>Thanks for booking a table at Alfredo Bistro for ${guests} guest(s) on
             ${new Date(date).toLocaleDateString()} at ${time}. We'll confirm shortly.</p>`,
    });
  } catch (err) {
    console.error('Reservation email failed:', err.message);
  }

  res.status(201).json({ success: true, data: reservation });
});

// @route  GET /api/reservations  (admin)
const getReservations = asyncHandler(async (req, res) => {
  const { status, date } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (date) filter.date = new Date(date);

  const reservations = await Reservation.find(filter).sort('-date');
  res.json({ success: true, count: reservations.length, data: reservations });
});

// @route  PUT /api/reservations/:id  (admin)
const updateReservationStatus = asyncHandler(async (req, res) => {
  const reservation = await Reservation.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true, runValidators: true }
  );
  if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });
  res.json({ success: true, data: reservation });
});

// @route  DELETE /api/reservations/:id  (admin)
const deleteReservation = asyncHandler(async (req, res) => {
  const reservation = await Reservation.findByIdAndDelete(req.params.id);
  if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });
  res.json({ success: true, message: 'Reservation deleted' });
});

module.exports = { createReservation, getReservations, updateReservationStatus, deleteReservation };
