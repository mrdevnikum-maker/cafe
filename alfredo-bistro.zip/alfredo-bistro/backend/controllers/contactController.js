const asyncHandler = require('../utils/asyncHandler');
const Contact = require('../models/Contact');
const sendEmail = require('../utils/sendEmail');

// @route  POST /api/contact
// @access Public
const submitContactForm = asyncHandler(async (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  const contact = await Contact.create({ name, email, phone, subject, message });

  try {
    await sendEmail({
      to: process.env.SMTP_USER,
      subject: `New enquiry: ${subject || 'General Enquiry'}`,
      html: `<p><b>From:</b> ${name} (${email})</p><p><b>Phone:</b> ${phone || 'N/A'}</p><p>${message}</p>`,
    });
  } catch (err) {
    console.error('Contact notification email failed:', err.message);
  }

  res.status(201).json({ success: true, data: contact, message: "Thanks for reaching out — we'll get back to you soon." });
});

// @route  GET /api/contact  (admin)
const getContactMessages = asyncHandler(async (req, res) => {
  const messages = await Contact.find().sort('-createdAt');
  res.json({ success: true, count: messages.length, data: messages });
});

// @route  PUT /api/contact/:id/read  (admin)
const markAsRead = asyncHandler(async (req, res) => {
  const message = await Contact.findByIdAndUpdate(req.params.id, { isRead: true }, { new: true });
  if (!message) return res.status(404).json({ success: false, message: 'Message not found' });
  res.json({ success: true, data: message });
});

module.exports = { submitContactForm, getContactMessages, markAsRead };
