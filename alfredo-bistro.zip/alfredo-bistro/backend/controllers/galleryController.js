const asyncHandler = require('../utils/asyncHandler');
const Gallery = require('../models/Gallery');

// @route  GET /api/gallery?category=
// @access Public
const getGalleryImages = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.category) filter.category = req.query.category;
  const images = await Gallery.find(filter).sort('displayOrder');
  res.json({ success: true, count: images.length, data: images });
});

// @route  POST /api/gallery  (admin)
const addGalleryImage = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'Image file is required' });
  const image = await Gallery.create({
    title: req.body.title,
    category: req.body.category,
    displayOrder: req.body.displayOrder || 0,
    image: `/uploads/${req.file.filename}`,
  });
  res.status(201).json({ success: true, data: image });
});

// @route  DELETE /api/gallery/:id  (admin)
const deleteGalleryImage = asyncHandler(async (req, res) => {
  const image = await Gallery.findByIdAndDelete(req.params.id);
  if (!image) return res.status(404).json({ success: false, message: 'Image not found' });
  res.json({ success: true, message: 'Image deleted' });
});

module.exports = { getGalleryImages, addGalleryImage, deleteGalleryImage };
