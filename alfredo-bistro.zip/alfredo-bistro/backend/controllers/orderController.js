const asyncHandler = require('../utils/asyncHandler');
const Order = require('../models/Order');
const FoodItem = require('../models/FoodItem');

// @route  POST /api/orders
// @access Private
const createOrder = asyncHandler(async (req, res) => {
  const { items, orderType, deliveryAddress, couponCode } = req.body;

  if (!items || items.length === 0) {
    return res.status(400).json({ success: false, message: 'Order must contain at least one item' });
  }

  // Re-price server-side from the DB so a tampered client payload can't set its own prices.
  const foodItems = await FoodItem.find({ _id: { $in: items.map((i) => i.foodItem) } });
  const priceMap = new Map(foodItems.map((f) => [f._id.toString(), f]));

  let totalAmount = 0;
  const orderItems = items.map((i) => {
    const food = priceMap.get(i.foodItem);
    if (!food) throw Object.assign(new Error(`Food item ${i.foodItem} not found`), { statusCode: 400 });
    totalAmount += food.price * i.quantity;
    return { foodItem: food._id, name: food.name, price: food.price, quantity: i.quantity };
  });

  // Placeholder discount logic; wire up the Coupon model here in the offers/coupon phase.
  const discountAmount = 0;

  const order = await Order.create({
    user: req.user._id,
    items: orderItems,
    orderType,
    deliveryAddress,
    totalAmount: totalAmount - discountAmount,
    couponCode,
    discountAmount,
  });

  res.status(201).json({ success: true, data: order });
});

// @route  GET /api/orders  (admin)
const getOrders = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const filter = {};
  if (status) filter.orderStatus = status;

  const orders = await Order.find(filter).populate('user', 'name email').sort('-createdAt');
  res.json({ success: true, count: orders.length, data: orders });
});

// @route  PUT /api/orders/:id  (admin)
const updateOrderStatus = asyncHandler(async (req, res) => {
  const order = await Order.findByIdAndUpdate(
    req.params.id,
    { orderStatus: req.body.orderStatus, paymentStatus: req.body.paymentStatus },
    { new: true, runValidators: true }
  );
  if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
  res.json({ success: true, data: order });
});

module.exports = { createOrder, getOrders, updateOrderStatus };
