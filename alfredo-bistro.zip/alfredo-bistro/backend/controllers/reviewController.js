const asyncHandler = require('../utils/asyncHandler');
const Review = require('../models/Review');
const FoodItem = require('../models/FoodItem');

// Recalculates a food item's average rating from its approved reviews.
const recalcRating = async (foodItemId) => {
  if (!foodItemId) return;
  const stats = await Review.aggregate([
    { $match: { foodItem: foodItemId, isApproved: true } },
    { $group: { _id: '$foodItem', avg: { $avg: '$rating' }, count: { $sum: 1 } } },
  ]);
  const { avg = 0, count = 0 } = stats[0] || {};
  await FoodItem.findByIdAndUpdate(foodItemId, { ratingAverage: avg, ratingCount: count });
};

// @route  GET /api/reviews?approved=true
// @access Public
const getReviews = asyncHandler(async (req, res) => {
  const filter = req.query.all === 'true' ? {} : { isApproved: true };
  const reviews = await Review.find(filter).populate('user', 'name').populate('foodItem', 'name').sort('-createdAt');
  res.json({ success: true, count: reviews.length, data: reviews });
});

// @route  POST /api/reviews
// @access Private
const createReview = asyncHandler(async (req, res) => {
  const review = await Review.create({
    user: req.user._id,
    foodItem: req.body.foodItem,
    rating: req.body.rating,
    comment: req.body.comment,
  });
  res.status(201).json({ success: true, data: review, message: 'Thanks! Your review will appear after moderation.' });
});

// @route  PUT /api/reviews/:id/approve  (admin)
const approveReview = asyncHandler(async (req, res) => {
  const review = await Review.findByIdAndUpdate(req.params.id, { isApproved: true }, { new: true });
  if (!review) return res.status(404).json({ success: false, message: 'Review not found' });
  await recalcRating(review.foodItem);
  res.json({ success: true, data: review });
});

// @route  DELETE /api/reviews/:id  (admin)
const deleteReview = asyncHandler(async (req, res) => {
  const review = await Review.findByIdAndDelete(req.params.id);
  if (!review) return res.status(404).json({ success: false, message: 'Review not found' });
  await recalcRating(review.foodItem);
  res.json({ success: true, message: 'Review deleted' });
});

module.exports = { getReviews, createReview, approveReview, deleteReview };
