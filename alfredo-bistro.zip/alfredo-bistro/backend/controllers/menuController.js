const asyncHandler = require('../utils/asyncHandler');
const FoodCategory = require('../models/FoodCategory');
const FoodItem = require('../models/FoodItem');

// @route  GET /api/menu/categories
// @access Public
const getCategories = asyncHandler(async (req, res) => {
  const categories = await FoodCategory.find({ isActive: true }).sort('displayOrder');
  res.json({ success: true, count: categories.length, data: categories });
});

// @route  POST /api/menu/categories  (admin)
const createCategory = asyncHandler(async (req, res) => {
  const category = await FoodCategory.create(req.body);
  res.status(201).json({ success: true, data: category });
});

// @route  PUT /api/menu/categories/:id  (admin)
const updateCategory = asyncHandler(async (req, res) => {
  const category = await FoodCategory.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!category) return res.status(404).json({ success: false, message: 'Category not found' });
  res.json({ success: true, data: category });
});

// @route  DELETE /api/menu/categories/:id  (admin)
const deleteCategory = asyncHandler(async (req, res) => {
  const category = await FoodCategory.findByIdAndDelete(req.params.id);
  if (!category) return res.status(404).json({ success: false, message: 'Category not found' });
  res.json({ success: true, message: 'Category deleted' });
});

// @route  GET /api/menu/items?category=&search=&veg=&page=&limit=&sort=
// @access Public
const getFoodItems = asyncHandler(async (req, res) => {
  const { category, search, veg, page = 1, limit = 12, sort = '-createdAt' } = req.query;

  const filter = { isAvailable: true };
  if (category) filter.category = category;
  if (veg === 'true') filter.isVeg = true;
  if (search) filter.$text = { $search: search };

  const skip = (Number(page) - 1) * Number(limit);

  const [items, total] = await Promise.all([
    FoodItem.find(filter).populate('category', 'name slug').sort(sort).skip(skip).limit(Number(limit)),
    FoodItem.countDocuments(filter),
  ]);

  res.json({
    success: true,
    count: items.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    data: items,
  });
});

// @route  GET /api/menu/items/:id
// @access Public
const getFoodItem = asyncHandler(async (req, res) => {
  const item = await FoodItem.findById(req.params.id).populate('category', 'name slug');
  if (!item) return res.status(404).json({ success: false, message: 'Food item not found' });
  res.json({ success: true, data: item });
});

// @route  POST /api/menu/items  (admin)
const createFoodItem = asyncHandler(async (req, res) => {
  if (req.file) req.body.image = `/uploads/${req.file.filename}`;
  const item = await FoodItem.create(req.body);
  res.status(201).json({ success: true, data: item });
});

// @route  PUT /api/menu/items/:id  (admin)
const updateFoodItem = asyncHandler(async (req, res) => {
  if (req.file) req.body.image = `/uploads/${req.file.filename}`;
  const item = await FoodItem.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!item) return res.status(404).json({ success: false, message: 'Food item not found' });
  res.json({ success: true, data: item });
});

// @route  DELETE /api/menu/items/:id  (admin)
const deleteFoodItem = asyncHandler(async (req, res) => {
  const item = await FoodItem.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ success: false, message: 'Food item not found' });
  res.json({ success: true, message: 'Food item deleted' });
});

module.exports = {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getFoodItems,
  getFoodItem,
  createFoodItem,
  updateFoodItem,
  deleteFoodItem,
};
