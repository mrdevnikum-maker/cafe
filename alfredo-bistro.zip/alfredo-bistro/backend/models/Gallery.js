const mongoose = require('mongoose');

const gallerySchema = new mongoose.Schema(
  {
    title: { type: String, trim: true, default: '' },
    image: { type: String, required: true },
    category: { type: String, enum: ['interior', 'food', 'events', 'team'], default: 'food' },
    displayOrder: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Gallery', gallerySchema);
