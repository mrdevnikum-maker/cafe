const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    foodItem: { type: mongoose.Schema.Types.ObjectId, ref: 'FoodItem' }, // optional: review a dish
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, required: true, trim: true },
    isApproved: { type: Boolean, default: false }, // admin moderates before it shows publicly
  },
  { timestamps: true }
);

module.exports = mongoose.model('Review', reviewSchema);
