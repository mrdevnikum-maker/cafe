// One-off script: creates the default admin user if none exists yet.
// Run with: npm run seed
require('dotenv').config();
const connectDB = require('../config/db');
const User = require('../models/User');

const seed = async () => {
  await connectDB();

  const existing = await User.findOne({ email: process.env.ADMIN_EMAIL });
  if (existing) {
    console.log('Admin already exists, skipping seed.');
    process.exit(0);
  }

  await User.create({
    name: 'Alfredo Bistro Admin',
    email: process.env.ADMIN_EMAIL,
    password: process.env.ADMIN_PASSWORD,
    role: 'admin',
  });

  console.log('Default admin created:', process.env.ADMIN_EMAIL);
  process.exit(0);
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
