const express = require('express');
const router = express.Router();
const {
  createReservation,
  getReservations,
  updateReservationStatus,
  deleteReservation,
} = require('../controllers/reservationController');
const { protect, authorize } = require('../middleware/auth');
const { validateRequest, reservationRules } = require('../middleware/validate');

router.post('/', reservationRules, validateRequest, createReservation); // guests + users

router.get('/', protect, authorize('admin'), getReservations);
router.put('/:id', protect, authorize('admin'), updateReservationStatus);
router.delete('/:id', protect, authorize('admin'), deleteReservation);

module.exports = router;
