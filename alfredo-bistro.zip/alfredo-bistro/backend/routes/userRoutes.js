const express = require('express');
const router = express.Router();
const {
  updateProfile,
  getMyOrders,
  getMyReservations,
  toggleWishlist,
  getWishlist,
} = require('../controllers/userController');
const { protect } = require('../middleware/auth');

router.use(protect); // every route below requires a logged-in user

router.put('/profile', updateProfile);
router.get('/orders', getMyOrders);
router.get('/reservations', getMyReservations);
router.get('/wishlist', getWishlist);
router.post('/wishlist/:foodItemId', toggleWishlist);

module.exports = router;
