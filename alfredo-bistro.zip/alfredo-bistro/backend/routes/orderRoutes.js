const express = require('express');
const router = express.Router();
const { createOrder, getOrders, updateOrderStatus } = require('../controllers/orderController');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, createOrder);
router.get('/', protect, authorize('admin'), getOrders);
router.put('/:id', protect, authorize('admin'), updateOrderStatus);

module.exports = router;
