const express = require('express');
const router = express.Router();
const { submitContactForm, getContactMessages, markAsRead } = require('../controllers/contactController');
const { protect, authorize } = require('../middleware/auth');
const { validateRequest, contactRules } = require('../middleware/validate');

router.post('/', contactRules, validateRequest, submitContactForm);
router.get('/', protect, authorize('admin'), getContactMessages);
router.put('/:id/read', protect, authorize('admin'), markAsRead);

module.exports = router;
