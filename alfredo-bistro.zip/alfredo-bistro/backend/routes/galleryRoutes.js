const express = require('express');
const router = express.Router();
const { getGalleryImages, addGalleryImage, deleteGalleryImage } = require('../controllers/galleryController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', getGalleryImages);
router.post('/', protect, authorize('admin'), upload.single('image'), addGalleryImage);
router.delete('/:id', protect, authorize('admin'), deleteGalleryImage);

module.exports = router;
