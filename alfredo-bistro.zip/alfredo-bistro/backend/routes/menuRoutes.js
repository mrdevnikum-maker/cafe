const express = require('express');
const router = express.Router();
const {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getFoodItems,
  getFoodItem,
  createFoodItem,
  updateFoodItem,
  deleteFoodItem,
} = require('../controllers/menuController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Public
router.get('/categories', getCategories);
router.get('/items', getFoodItems);
router.get('/items/:id', getFoodItem);

// Admin only
router.post('/categories', protect, authorize('admin'), createCategory);
router.put('/categories/:id', protect, authorize('admin'), updateCategory);
router.delete('/categories/:id', protect, authorize('admin'), deleteCategory);

router.post('/items', protect, authorize('admin'), upload.single('image'), createFoodItem);
router.put('/items/:id', protect, authorize('admin'), upload.single('image'), updateFoodItem);
router.delete('/items/:id', protect, authorize('admin'), deleteFoodItem);

module.exports = router;
